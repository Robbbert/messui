// For licensing and usage information, read docs/winui_license.txt
//****************************************************************************

#ifndef WINUI_FILE_H
#define WINUI_FILE_H

// from windows fileio.c
extern void set_pathlist(int file_type,const char *new_rawpath);

#define OSD_FILETYPE_ICON 1001

#endif

