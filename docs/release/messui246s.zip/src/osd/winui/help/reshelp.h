// Include the Microsoft Developer Studio generated Help ID include file.
//
#include "..\resource.hm"
#include "mameui.hm"
