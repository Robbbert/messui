//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by mess.rc
//
#define ID_FILE_LOADSTATE_NEWUI         3101
#define ID_FILE_SAVESTATE               3102
#define ID_FILE_SAVESTATE_AS            3103
#define ID_FILE_SAVESCREENSHOT          3104
#define ID_FILE_EXIT_NEWUI              3105
#define ID_EDIT_PASTE                   3106
#define ID_FILE_HIDEMENUBAR             3107
#define ID_OPTIONS_KEYBOARD             3108
#define ID_OPTIONS_CONFIGURATION        3109
#define ID_OPTIONS_DIPSWITCHES          3110
#define ID_OPTIONS_MISCINPUT            3111
#define ID_OPTIONS_USEMOUSE             3112
#define ID_FILE_TOGGLEMENUBAR           3113
#define ID_OPTIONS_SOFTRESET            3114
#define ID_OPTIONS_HARDRESET            3115
#define ID_OPTIONS_FRAMESKIP            3116
#define ID_OPTIONS_PAUSE                3117
#define ID_OPTIONS_JOYSTICKS            3118
#define ID_OPTIONS_ANALOGCONTROLS       3119
#define ID_FILE_FULLSCREEN              3120
#define ID_OPTIONS_TOGGLEFPS            3122
#define ID_KEYBOARD_EMULATED            3124
#define ID_KEYBOARD_NATURAL             3125
#define ID_KEYBOARD_CUSTOMIZE           3126
#define ID_VIDEO_ROTATE_0               3127
#define ID_VIDEO_ROTATE_90              3128
#define ID_VIDEO_ROTATE_180             3129
#define ID_VIDEO_ROTATE_270             3130
#define ID_THROTTLE_50                  3131
#define ID_THROTTLE_100                 3132
#define ID_THROTTLE_200                 3133
#define ID_THROTTLE_500                 3134
#define ID_THROTTLE_1000                3135
#define ID_THROTTLE_UNTHROTTLED         3136
#define ID_FRAMESKIP_AUTO               3137
#define ID_DEVICES                      3138
#define ID_HELP_ABOUT_NEWUI             3139
#define ID_HELP_ABOUTSYSTEM             3140
#define ID_FILE_OLDUI                   3141
#define ID_FILE_UIACTIVE                3142
#define IDC_SHOW_MENU                   3143
#define IDI_ICON_CART                   3200
#define IDI_ICON_HARD                   3201
#define IDI_ICON_CASS                   3202
#define IDI_ICON_FLOP                   3203
#define IDI_ICON_PRIN                   3204
#define IDI_ICON_SERL                   3205
#define IDI_ICON_SNAP                   3206
#define IDR_RUNTIME_MENU                3300

